package com.example.caterease_catering_services

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
