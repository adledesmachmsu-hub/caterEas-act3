import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/cart_item.dart';

// Activity 1: Shopping cart app using Provider
// Activity 2: Use ChangeNotifier with Provider to update UI when data changes
class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];
  final List<CartItem> _favorites = [];
  static const String _cartKey = 'cart_items';
  static const String _favoritesKey = 'favorite_items';

  List<CartItem> get items => _items;
  List<CartItem> get favorites => _favorites;

  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);
  int get favoriteCount => _favorites.length;

  double get totalPrice =>
      _items.fold(0.0, (sum, item) => sum + item.totalPrice);

  // Initialize cart from SharedPreferences
  Future<void> loadCart() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // Load cart items
      final cartJson = prefs.getString(_cartKey);
      if (cartJson != null) {
        final List<dynamic> cartList = json.decode(cartJson);
        _items.clear();
        _items.addAll(cartList.map((item) => CartItem.fromJson(item)));
      }

      // Load favorite items
      final favoritesJson = prefs.getString(_favoritesKey);
      if (favoritesJson != null) {
        final List<dynamic> favoritesList = json.decode(favoritesJson);
        _favorites.clear();
        _favorites.addAll(favoritesList.map((item) => CartItem.fromJson(item)));
      }

      notifyListeners();
    } catch (e) {
      if (kDebugMode) {
        print('Error loading cart: $e');
      }
    }
  }

  // Save cart to SharedPreferences
  Future<void> _saveCart() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final cartJson =
          json.encode(_items.map((item) => item.toJson()).toList());
      await prefs.setString(_cartKey, cartJson);
    } catch (e) {
      if (kDebugMode) {
        print('Error saving cart: $e');
      }
    }
  }

  // Save favorites to SharedPreferences
  Future<void> _saveFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favoritesJson =
          json.encode(_favorites.map((item) => item.toJson()).toList());
      await prefs.setString(_favoritesKey, favoritesJson);
    } catch (e) {
      if (kDebugMode) {
        print('Error saving favorites: $e');
      }
    }
  }

  void addItem(CartItem item) {
    if (!item.isAvailable) {
      throw Exception('Item is not available');
    }

    final existingIndex =
        _items.indexWhere((existingItem) => existingItem.id == item.id);

    if (existingIndex >= 0) {
      _items[existingIndex].quantity++;
    } else {
      _items.add(item);
    }
    notifyListeners();
    _saveCart(); // Activity 2: Notify listeners when data changes
  }

  void removeItem(String itemId) {
    _items.removeWhere((item) => item.id == itemId);
    notifyListeners();
    _saveCart();
  }

  void updateQuantity(String itemId, int quantity) {
    final index = _items.indexWhere((item) => item.id == itemId);
    if (index >= 0) {
      if (quantity <= 0) {
        _items.removeAt(index);
      } else {
        _items[index].quantity = quantity;
      }
      notifyListeners();
      _saveCart();
    }
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
    _saveCart();
  }

  // Favorites functionality
  void addToFavorites(CartItem item) {
    if (!_favorites.any((fav) => fav.id == item.id)) {
      _favorites.add(item);
      notifyListeners();
      _saveFavorites();
    }
  }

  void removeFromFavorites(String itemId) {
    _favorites.removeWhere((item) => item.id == itemId);
    notifyListeners();
    _saveFavorites();
  }

  bool isFavorite(String itemId) {
    return _favorites.any((item) => item.id == itemId);
  }

  // Search and filter functionality
  List<CartItem> searchItems(String query) {
    if (query.isEmpty) return _items;

    return _items
        .where((item) =>
            item.name.toLowerCase().contains(query.toLowerCase()) ||
            item.description.toLowerCase().contains(query.toLowerCase()) ||
            item.category.toLowerCase().contains(query.toLowerCase()))
        .toList();
  }

  List<CartItem> filterByCategory(String category) {
    return _items.where((item) => item.category == category).toList();
  }

  List<CartItem> filterByDietaryRestriction(String restriction) {
    switch (restriction.toLowerCase()) {
      case 'vegetarian':
        return _items.where((item) => item.isVegetarian).toList();
      case 'vegan':
        return _items.where((item) => item.isVegan).toList();
      case 'gluten-free':
        return _items.where((item) => item.isGlutenFree).toList();
      default:
        return _items;
    }
  }

  // Validation methods
  bool validateCart() {
    return _items.every((item) => item.isAvailable && item.quantity > 0);
  }

  List<String> getValidationErrors() {
    List<String> errors = [];
    for (var item in _items) {
      if (!item.isAvailable) {
        errors.add('${item.name} is no longer available');
      }
      if (item.quantity <= 0) {
        errors.add('${item.name} has invalid quantity');
      }
    }
    return errors;
  }

  // Get cart summary
  Map<String, dynamic> getCartSummary() {
    return {
      'totalItems': itemCount,
      'totalPrice': totalPrice,
      'categories': _items.map((item) => item.category).toSet().toList(),
      'dietaryRestrictions':
          _items.where((item) => item.hasDietaryRestrictions).length,
      'averageRating': _items.isNotEmpty
          ? _items.map((item) => item.rating).reduce((a, b) => a + b) /
              _items.length
          : 0.0,
    };
  }
}
