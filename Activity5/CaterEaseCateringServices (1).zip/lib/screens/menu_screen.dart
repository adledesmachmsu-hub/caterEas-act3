import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../models/cart_item.dart';
import 'shopping_cart_screen.dart';

Widget buildMenuItem(
  BuildContext context,
  String name,
  String description,
  String price,
  IconData icon,
  String id,
  String category,
  double rating,
  bool isVegetarian,
  bool isVegan,
  bool isGlutenFree,
) {
  return Card(
    margin: const EdgeInsets.only(bottom: 16),
    elevation: 3,
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.orange.shade100,
                child: Icon(icon, color: Colors.orange),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          '$rating',
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                    if (isVegetarian || isVegan || isGlutenFree) ...[
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 8,
                        children: [
                          if (isVegan)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.green.shade100,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Vegan',
                                style: TextStyle(
                                  color: Colors.green.shade700,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          if (isVegetarian)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade100,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Vegetarian',
                                style: TextStyle(
                                  color: Colors.blue.shade700,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          if (isGlutenFree)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.purple.shade100,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Gluten-Free',
                                style: TextStyle(
                                  color: Colors.purple.shade700,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              Column(
                children: [
                  Text(
                    price,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Consumer<CartProvider>(
                    builder: (context, cartProvider, child) {
                      return Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(
                              cartProvider.isFavorite(id)
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: cartProvider.isFavorite(id)
                                  ? Colors.red
                                  : Colors.grey,
                            ),
                            onPressed: () {
                              final cartItem = CartItem(
                                id: id,
                                name: name,
                                description: description,
                                price: double.parse(price
                                    .replaceAll('₱', '')
                                    .replaceAll(',', '')),
                                imageUrl: '',
                                category: category,
                                rating: rating,
                                isVegetarian: isVegetarian,
                                isVegan: isVegan,
                                isGlutenFree: isGlutenFree,
                              );

                              if (cartProvider.isFavorite(id)) {
                                cartProvider.removeFromFavorites(id);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content:
                                        Text('$name removed from favorites'),
                                    backgroundColor: Colors.orange,
                                  ),
                                );
                              } else {
                                cartProvider.addToFavorites(cartItem);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('$name added to favorites'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            },
                          ),
                          ElevatedButton(
                            onPressed: () {
                              try {
                                final cartItem = CartItem(
                                  id: id,
                                  name: name,
                                  description: description,
                                  price: double.parse(price
                                      .replaceAll('₱', '')
                                      .replaceAll(',', '')),
                                  imageUrl: '',
                                  category: category,
                                  rating: rating,
                                  isVegetarian: isVegetarian,
                                  isVegan: isVegan,
                                  isGlutenFree: isGlutenFree,
                                );
                                cartProvider.addItem(cartItem);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('$name added to cart!'),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              } catch (e) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('Error: ${e.toString()}'),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).primaryColor,
                              foregroundColor: Colors.white,
                              minimumSize: const Size(80, 30),
                            ),
                            child: const Text('Add',
                                style: TextStyle(fontSize: 12)),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

// CaterEase Menu Screen - Displays appetizers, main courses, and desserts
class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Our Menu'),
          backgroundColor: Theme.of(context).primaryColor,
          foregroundColor: Colors.white,
          actions: [
            Consumer<CartProvider>(
              builder: (context, cartProvider, child) {
                return Stack(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.shopping_cart),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const ShoppingCartScreen(),
                          ),
                        );
                      },
                    ),
                    if (cartProvider.itemCount > 0)
                      Positioned(
                        right: 8,
                        top: 8,
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          constraints: const BoxConstraints(
                            minWidth: 16,
                            minHeight: 16,
                          ),
                          child: Text(
                            '${cartProvider.itemCount}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ],
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            tabs: [
              Tab(icon: Icon(Icons.restaurant), text: 'Appetizers'),
              Tab(icon: Icon(Icons.set_meal), text: 'Main Course'),
              Tab(icon: Icon(Icons.cake), text: 'Desserts'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            AppetizersTab(),
            MainCourseTab(),
            DessertsTab(),
          ],
        ),
      ),
    );
  }
}

class AppetizersTab extends StatelessWidget {
  const AppetizersTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        buildMenuItem(
          context,
          'Spring Rolls',
          'Crispy vegetable spring rolls with sweet chili sauce',
          '₱450',
          Icons.restaurant,
          'spring_rolls',
          'Appetizers',
          4.5,
          true,
          true,
          false,
        ),
        buildMenuItem(
          context,
          'Bruschetta',
          'Toasted bread with tomatoes, garlic, and basil',
          '₱369',
          Icons.restaurant,
          'bruschetta',
          'Appetizers',
          4.2,
          true,
          false,
          false,
        ),
        buildMenuItem(
          context,
          'Chicken Wings',
          'Spicy buffalo wings with ranch dressing',
          '₱299',
          Icons.restaurant,
          'chicken_wings',
          'Appetizers',
          4.7,
          false,
          false,
          false,
        ),
      ],
    );
  }
}

class MainCourseTab extends StatelessWidget {
  const MainCourseTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        buildMenuItem(
          context,
          'Grilled Salmon',
          'Fresh Atlantic salmon with lemon butter sauce',
          '₱459',
          Icons.set_meal,
          'grilled_salmon',
          'Main Course',
          4.8,
          false,
          false,
          false,
        ),
        buildMenuItem(
          context,
          'Beef Steak',
          'Premium ribeye steak with garlic mashed potatoes',
          '₱430',
          Icons.set_meal,
          'beef_steak',
          'Main Course',
          4.6,
          false,
          false,
          false,
        ),
        buildMenuItem(
          context,
          'Pasta Carbonara',
          'Creamy pasta with bacon and parmesan',
          '₱459',
          Icons.set_meal,
          'pasta_carbonara',
          'Main Course',
          4.4,
          false,
          false,
          false,
        ),
      ],
    );
  }
}

class DessertsTab extends StatelessWidget {
  const DessertsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        buildMenuItem(
          context,
          'Chocolate Cake',
          'Rich chocolate layer cake with ganache',
          '₱399',
          Icons.cake,
          'chocolate_cake',
          'Desserts',
          4.9,
          false,
          false,
          false,
        ),
        buildMenuItem(
          context,
          'Tiramisu',
          'Classic Italian coffee-flavored dessert',
          '₱149',
          Icons.cake,
          'tiramisu',
          'Desserts',
          4.7,
          false,
          false,
          false,
        ),
        buildMenuItem(
          context,
          'Ice Cream Sundae',
          'Three scoops with toppings of your choice',
          '₱599',
          Icons.cake,
          'ice_cream_sundae',
          'Desserts',
          4.3,
          false,
          false,
          false,
        ),
      ],
    );
  }
}
