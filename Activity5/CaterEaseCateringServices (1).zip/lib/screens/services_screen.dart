import 'package:flutter/material.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Our Services',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hero Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Theme.of(context).primaryColor,
                    Colors.orange.shade300,
                  ],
                ),
              ),
              child: const Column(
                children: [
                  Icon(
                    Icons.room_service,
                    size: 60,
                    color: Colors.white,
                  ),
                  SizedBox(height: 12),
                  Text(
                    'Premium Catering Services',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Tailored to make your events unforgettable',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Services List
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'What We Offer',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildServiceCard(
                    context,
                    icon: Icons.celebration,
                    title: 'Wedding Catering',
                    description:
                        'Make your special day perfect with our elegant wedding catering services. From intimate gatherings to grand celebrations.',
                    color: Colors.pink,
                  ),
                  const SizedBox(height: 12),
                  _buildServiceCard(
                    context,
                    icon: Icons.business_center,
                    title: 'Corporate Events',
                    description:
                        'Professional catering for business meetings, conferences, and corporate parties. Impress your clients and colleagues.',
                    color: Colors.blue,
                  ),
                  const SizedBox(height: 12),
                  _buildServiceCard(
                    context,
                    icon: Icons.cake,
                    title: 'Birthday Parties',
                    description:
                        'Celebrate birthdays with delicious food and exceptional service. Custom menus for all ages and preferences.',
                    color: Colors.purple,
                  ),
                  const SizedBox(height: 12),
                  _buildServiceCard(
                    context,
                    icon: Icons.school,
                    title: 'School Events',
                    description:
                        'Nutritious and kid-friendly catering for school functions, graduations, and educational events.',
                    color: Colors.green,
                  ),
                  const SizedBox(height: 12),
                  _buildServiceCard(
                    context,
                    icon: Icons.home,
                    title: 'Private Parties',
                    description:
                        'Intimate home gatherings, dinner parties, and family celebrations with personalized menus.',
                    color: Colors.orange,
                  ),
                  const SizedBox(height: 12),
                  _buildServiceCard(
                    context,
                    icon: Icons.festival,
                    title: 'Festival Catering',
                    description:
                        'Large-scale event catering for festivals, concerts, and outdoor events. High-volume service with quality.',
                    color: Colors.teal,
                  ),
                  const SizedBox(height: 24),
                  // Call to Action
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Theme.of(context).primaryColor.withOpacity(0.3),
                      ),
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.phone_in_talk,
                          size: 40,
                          color: Color(0xFFFF6B35),
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Ready to Book?',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Contact us today to discuss your event needs',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 14),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ElevatedButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, '/booking-form');
                              },
                              icon: const Icon(Icons.book_online),
                              label: const Text('Book Now'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Theme.of(context).primaryColor,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 24,
                                  vertical: 12,
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            OutlinedButton.icon(
                              onPressed: () {
                                Navigator.pushNamed(context, '/contact');
                              },
                              icon: const Icon(Icons.contact_mail),
                              label: const Text('Contact Us'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: Theme.of(context).primaryColor,
                                side: BorderSide(
                                  color: Theme.of(context).primaryColor,
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 24,
                                  vertical: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String description,
    required Color color,
  }) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                icon,
                size: 32,
                color: color,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
