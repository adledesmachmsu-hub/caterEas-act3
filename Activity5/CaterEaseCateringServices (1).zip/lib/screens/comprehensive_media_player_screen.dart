import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:audioplayers/audioplayers.dart';

// Activity 19: Build a video + audio player app with play, pause, and stop buttons
class ComprehensiveMediaPlayerScreen extends StatefulWidget {
  const ComprehensiveMediaPlayerScreen({super.key});

  @override
  State<ComprehensiveMediaPlayerScreen> createState() =>
      _ComprehensiveMediaPlayerScreenState();
}

class _ComprehensiveMediaPlayerScreenState
    extends State<ComprehensiveMediaPlayerScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;

  // Video player controllers
  late VideoPlayerController _videoController1;
  late VideoPlayerController _videoController2;
  ChewieController? _chewieController1;
  ChewieController? _chewieController2;

  // Audio player
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isAudioPlaying = false;
  Duration _audioDuration = Duration.zero;
  Duration _audioPosition = Duration.zero;

  // Playlist
  final List<MediaItem> _videoPlaylist = [
    MediaItem(
      id: '1',
      title: 'Sample Video 1',
      description: 'A sample video for demonstration',
      url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
      type: MediaType.video,
    ),
    MediaItem(
      id: '2',
      title: 'Sample Video 2',
      description: 'Another sample video',
      url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
      type: MediaType.video,
    ),
  ];

  final List<MediaItem> _audioPlaylist = [
    MediaItem(
      id: '3',
      title: 'Sample Audio 1',
      description: 'A sample audio track',
      url: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
      type: MediaType.audio,
    ),
    MediaItem(
      id: '4',
      title: 'Sample Audio 2',
      description: 'Another sample audio track',
      url: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
      type: MediaType.audio,
    ),
  ];

  int _currentAudioIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initializeVideoPlayers();
    _initializeAudioPlayer();
  }

  void _initializeVideoPlayers() {
    // Initialize first video
    _videoController1 = VideoPlayerController.networkUrl(
      Uri.parse(_videoPlaylist[0].url),
    );
    _videoController1.initialize().then((_) {
      setState(() {});
    });

    _chewieController1 = ChewieController(
      videoPlayerController: _videoController1,
      autoPlay: false,
      looping: false,
      showControls: true,
    );

    // Initialize second video
    _videoController2 = VideoPlayerController.networkUrl(
      Uri.parse(_videoPlaylist[1].url),
    );
    _videoController2.initialize().then((_) {
      setState(() {});
    });

    _chewieController2 = ChewieController(
      videoPlayerController: _videoController2,
      autoPlay: false,
      looping: false,
      showControls: true,
    );
  }

  void _initializeAudioPlayer() {
    _audioPlayer.onDurationChanged.listen((duration) {
      setState(() {
        _audioDuration = duration;
      });
    });

    _audioPlayer.onPositionChanged.listen((position) {
      setState(() {
        _audioPosition = position;
      });
    });

    _audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() {
        _isAudioPlaying = state == PlayerState.playing;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _videoController1.dispose();
    _videoController2.dispose();
    _chewieController1?.dispose();
    _chewieController2?.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _playAudio() async {
    try {
      await _audioPlayer
          .play(UrlSource(_audioPlaylist[_currentAudioIndex].url));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error playing audio: $e')),
      );
    }
  }

  Future<void> _pauseAudio() async {
    await _audioPlayer.pause();
  }

  Future<void> _stopAudio() async {
    await _audioPlayer.stop();
  }

  void _nextAudio() {
    if (_currentAudioIndex < _audioPlaylist.length - 1) {
      setState(() {
        _currentAudioIndex++;
      });
      _stopAudio();
    }
  }

  void _previousAudio() {
    if (_currentAudioIndex > 0) {
      setState(() {
        _currentAudioIndex--;
      });
      _stopAudio();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comprehensive Media Player'),
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.video_library), text: 'Videos'),
            Tab(icon: Icon(Icons.audiotrack), text: 'Audio'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildVideoTab(),
          _buildAudioTab(),
        ],
      ),
    );
  }

  Widget _buildVideoTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Video Player with Controls',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Video 1
          Card(
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _videoPlaylist[0].title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _videoPlaylist[0].description,
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.black,
                    ),
                    child: _videoController1.value.isInitialized
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Chewie(controller: _chewieController1!),
                          )
                        : const Center(
                            child:
                                CircularProgressIndicator(color: Colors.white),
                          ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController1?.play();
                        },
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Play'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController1?.pause();
                        },
                        icon: const Icon(Icons.pause),
                        label: const Text('Pause'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController1?.seekTo(Duration.zero);
                          _chewieController1?.pause();
                        },
                        icon: const Icon(Icons.stop),
                        label: const Text('Stop'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Video 2
          Card(
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _videoPlaylist[1].title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _videoPlaylist[1].description,
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    height: 250,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.black,
                    ),
                    child: _videoController2.value.isInitialized
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Chewie(controller: _chewieController2!),
                          )
                        : const Center(
                            child:
                                CircularProgressIndicator(color: Colors.white),
                          ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController2?.play();
                        },
                        icon: const Icon(Icons.play_arrow),
                        label: const Text('Play'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController2?.pause();
                        },
                        icon: const Icon(Icons.pause),
                        label: const Text('Pause'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                        ),
                      ),
                      ElevatedButton.icon(
                        onPressed: () {
                          _chewieController2?.seekTo(Duration.zero);
                          _chewieController2?.pause();
                        },
                        icon: const Icon(Icons.stop),
                        label: const Text('Stop'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAudioTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Audio Player with Playlist',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Current audio info
          Card(
            elevation: 8,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Container(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Icon(Icons.audiotrack, size: 80, color: Colors.orange),
                  const SizedBox(height: 16),
                  Text(
                    _audioPlaylist[_currentAudioIndex].title,
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _audioPlaylist[_currentAudioIndex].description,
                    style: const TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 16),

                  // Progress bar
                  if (_audioDuration.inMilliseconds > 0)
                    Column(
                      children: [
                        Slider(
                          value: _audioPosition.inMilliseconds.toDouble(),
                          max: _audioDuration.inMilliseconds.toDouble(),
                          onChanged: (value) {
                            _audioPlayer
                                .seek(Duration(milliseconds: value.toInt()));
                          },
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_formatDuration(_audioPosition)),
                            Text(_formatDuration(_audioDuration)),
                          ],
                        ),
                      ],
                    ),

                  const SizedBox(height: 24),

                  // Control buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        onPressed: _previousAudio,
                        icon: const Icon(Icons.skip_previous, size: 40),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.grey[200],
                        ),
                      ),
                      ElevatedButton(
                        onPressed: _isAudioPlaying ? _pauseAudio : _playAudio,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).primaryColor,
                          foregroundColor: Colors.white,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(20),
                        ),
                        child: Icon(
                          _isAudioPlaying ? Icons.pause : Icons.play_arrow,
                          size: 40,
                        ),
                      ),
                      IconButton(
                        onPressed: _nextAudio,
                        icon: const Icon(Icons.skip_next, size: 40),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.grey[200],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Stop button
                  ElevatedButton.icon(
                    onPressed: _stopAudio,
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Playlist
          const Text(
            'Audio Playlist',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _audioPlaylist.length,
            itemBuilder: (context, index) {
              final audio = _audioPlaylist[index];
              final isCurrent = index == _currentAudioIndex;

              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                color: isCurrent
                    ? Theme.of(context).primaryColor.withOpacity(0.1)
                    : null,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isCurrent
                        ? Theme.of(context).primaryColor
                        : Colors.grey,
                    child: Icon(
                      isCurrent ? Icons.audiotrack : Icons.music_note,
                      color: Colors.white,
                    ),
                  ),
                  title: Text(
                    audio.title,
                    style: TextStyle(
                      fontWeight:
                          isCurrent ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                  subtitle: Text(audio.description),
                  trailing: isCurrent
                      ? const Icon(Icons.equalizer, color: Colors.orange)
                      : const Icon(Icons.play_arrow),
                  onTap: () {
                    setState(() {
                      _currentAudioIndex = index;
                    });
                    _stopAudio();
                  },
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }
}

enum MediaType { video, audio }

class MediaItem {
  final String id;
  final String title;
  final String description;
  final String url;
  final MediaType type;

  MediaItem({
    required this.id,
    required this.title,
    required this.description,
    required this.url,
    required this.type,
  });
}
