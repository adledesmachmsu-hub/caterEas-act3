package com.example.parkingspace

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
